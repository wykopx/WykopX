## beautify-css - modified from v1.6.12

Beautify-css was **heavily** modified from its source:

https://github.com/beautify-web/js-beautify/blob/v1.6.12/js/lib/beautify-css.js

After this version the source repo split the file and built it using webpack.

Our version has more options & modes. It should be considered a fork of the original.
